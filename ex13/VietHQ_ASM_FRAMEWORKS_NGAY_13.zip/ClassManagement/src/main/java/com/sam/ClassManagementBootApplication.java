package com.sam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassManagementBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassManagementBootApplication.class, args);
	}
}
