'use strict';
angular.module('mainApp').constant("Config", {
    api: 'http://localhost:8080/maxcentive-backend/'
});
